package com.example.audioplayer
        ;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.net.Uri;
import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    SeekBar sb;
    ImageButton btplay,btpause,btopen,btstop;
    TextView tv;

    int duration =0,current =0;

    boolean finish=false,pause=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sb = findViewById(R.id.sb);
        btplay = findViewById(R.id.btplay);
        btopen = findViewById(R.id.btopen);
        btpause = findViewById(R.id.btpause);
        btstop = findViewById(R.id.btstop);
        tv = findViewById(R.id.tv);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int n = sb.getProgress();
                GlobalMedia.mp.seekTo(n*1000);
                tv.setText(""+n+"/"+duration);
            }
        });


        btopen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii = new Intent(Intent.ACTION_GET_CONTENT);
                ii.setType("audio/*");
                startActivityForResult(Intent.createChooser(ii,"Select your song"),121);
            }
        });
        btpause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(GlobalMedia.mp!=null)
                {
                    GlobalMedia.mp.pause();
                    pause = true;
                }
            }
        });

        btplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(GlobalMedia.mp!=null)
                {
                    GlobalMedia.mp.start();
                    pause = false;
                }
            }
        });
        btstop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(GlobalMedia.mp!=null)
                {
                    GlobalMedia.mp.stop();
                    duration = 0;
                    current = 0;
                    sb.setProgress(0);
                    tv.setText("0/0");
                    finish = true;
                    pause = true;
                }
            }
        });


    }
    public void onActivityResult(int reqCode,int resCode,Intent data)
    {
        if(resCode == RESULT_OK && reqCode == 121)
        {
             Uri uri = data.getData();
             GlobalMedia.mp = MediaPlayer.create(getApplicationContext(),uri);
            GlobalMedia.mp.start();
            notifyMe(uri);

            duration = GlobalMedia.mp.getDuration();
            duration = duration/1000;
            tv.setText("0/"+duration);

            sb.setMax(duration);

            finish = false;
            pause = false;

            new Thread(new Runnable() {
                @Override
                public void run() {

                    while(!finish)
                    {
                        if(!pause)
                        {
                            current = GlobalMedia.mp.getCurrentPosition();
                            current = current/1000;
                            sb.setProgress(current);

                            tv.post(new Runnable() {
                                @Override
                                public void run() {
                                    tv.setText(""+current+"/"+duration);
                                }
                            });

                        }
                        try{Thread.sleep(1000);}
                        catch (Exception e){}
                        if(current == duration)
                        {
                            pause = true;
                            current = 0;
                            duration = 0;
                            sb.setProgress(0);
                            tv.setText("0/0");
                            GlobalMedia.mp.stop();
                            GlobalMedia.mp=null;
                        }

                    }

                }
            }).start();
        }
    }
void notifyMe(Uri uri)
{
    String s = uri.getPath();
    int p = s.lastIndexOf("/");
    String song = s.substring(p+1);

    Intent i1 = new Intent(getApplicationContext(),MainActivity.class);

    PendingIntent pi1 = PendingIntent.getActivity(getApplicationContext(),0,i1,PendingIntent.FLAG_IMMUTABLE) ;

    NotificationChannel channel = new NotificationChannel("2024","Your Audio ",NotificationManager.IMPORTANCE_HIGH);

    NotificationCompat.Builder noti = new NotificationCompat.Builder(getApplicationContext(),"2024")
            .setContentText("MY AUDIO")
            .setContentText(song)
            .setContentIntent(pi1)
            .setSmallIcon(R.drawable.baseline_audiotrack_24);

    NotificationManager man = getSystemService(NotificationManager.class); // to get the services from the mobile

    man.createNotificationChannel(channel); // that create notification

    man.notify(1001,noti.build());  // id for the particular id
}

}