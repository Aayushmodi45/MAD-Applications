package com.example.audioplayer;

import android.media.MediaPlayer;

public class GlobalMedia {
    public static MediaPlayer mp = null;
}
